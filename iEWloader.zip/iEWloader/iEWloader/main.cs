﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iEWloader
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Management;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    public partial class main : MetroForm
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        
        static extern bool VirtualProtect(IntPtr lpAddress, uint dwSize, int flag, out int na);
        [DllImport("Kernel32.dll", EntryPoint = "RtlZeroMemory", SetLastError = false)]
        static extern void ZeroMemory(IntPtr dest, IntPtr size);
        #region Protection
        #region Protection Entry
        /// <summary>
        /// Entry point of Protection
        /// </summary>
        /// <param name="StartProtection_">If you want anti debugger to start automaticly</param>
        public void Protection(bool StartAntiDebugger = false)
        {
            if (StartAntiDebugger)
                StartProtection();
        }
        #endregion

        #region Vars
        int ExceptionCount = 0;
        int MaxExceptions = 3;
        public bool HasAntiDebuggerStarted = false;

        #endregion

        /*~~~~~~~~~~~~~~~~~~~~~~~~~<-Milf->~~~~~~~~~~~~~~~~~~~~~~~~~*/
        #region Inports
        [DllImport("kernel32.dll")]
        public static extern IntPtr GetModuleHandle(string lpModuleName);
        #endregion

        /*~~~~~~~~~~~~~~~~~~~~~~~~~<-Milf->~~~~~~~~~~~~~~~~~~~~~~~~~*/
        #region "Anti" Debugging
        //This "Anti" Debugging class will just detect if a process is open and if it is this will close. You could add more. It's a very simple class.
        #region AntiDebugging Vars
        bool Anti_Started = false;

        #endregion


        #region Detectable Processes
        //Feal free to add more. Btw it works like if(Processes[i].TitleText.ToLower().Contails(DetectableProcesses[j]) { Exit(); }
        string[] DetectableProcesses = new string[] {
        "IDA",
        "MegaDumper",
        "WPE PRO",
        "The Wireshark Network Analyzer",
        "WinDbg",
        "OllyDbg",
        "Colasoft Capsa",
        "Microsoft Network Monitor",
        "Fiddler",
        "SmartSniff",
        "Immunity Debugger",
        "Process Explorer",
        "PE Tools",
        "AQtime",
        "DS-5 Debug",
        "Dbxtool",
        "Topaz",
        "FusionDebug",
        "NetBeans",
        "Rational Purify",
        ".NET Reflector",
        "Cheat Engine",
        "Sigma Engine" };
        #endregion

        #region Declairing Threads
        Thread Thread_Protect;
        ThreadPriority Thread_Protect_Priority = ThreadPriority.AboveNormal;

        Thread Thread_ProtectCheck;
        ThreadPriority Thread_ProtectCheck_Priority = ThreadPriority.Highest;
        #endregion

        #region Protection Functions
        /// <summary>
        /// This functions will be called of a debugger is detected running...
        /// </summary>
        /// <param name="Debugger">This is the name of the debugger detected</param>
        /// <param name="Lcoation">This is where the debugger is located</param>
        private void DebuggerDetected(string Debugger, string Lcoation, int ProcessID)
        {
            //I would do this in a event but I'm not good with events :( Soz
            Environment.Exit(Environment.ExitCode);

            //Could do something like this
            /*
             * Function:
             * void BanUser(string BanReason, string TokenID);
             * 
             * Useage:
             * if(Debugger.Length > 0 && Lcoation.Length > 0)
             *      BanUser("Debugger Detected. Debugger: " + Debugger + ". Located: " + Location, UserID);
             * else
             *     BanUser("Unknown", UserID);
             * //And Could Add a check to make sure UserID is valid and the ID matches IP Or HardwareID other wise anyone could ban anyone without validation
             * //But if UserID isn't valid you could ban that IP
             */
        }

        private void ProtectVoid()
        {
            try
            {
                while (true)
                {
                    //Thread checks
                    if (!Thread_ProtectCheck.IsAlive)
                        Environment.Exit(Environment.ExitCode);
                    if (Thread_ProtectCheck.Priority <= Thread_ProtectCheck_Priority)
                        Thread_ProtectCheck.Priority = Thread_ProtectCheck_Priority;


                    #region Method one
                    Process[] Processes = Process.GetProcesses();
                    for (int ProcessCycle = 0; ProcessCycle < Processes.Length; ProcessCycle++)
                    {
                        string ProcTitle = Processes[ProcessCycle].MainWindowTitle;
                        Process Process_ = Processes[ProcessCycle];

                        for (int i = 0; i < DetectableProcesses.Length; i++)
                            if (ProcTitle.Contains(DetectableProcesses[i]))
                                DebuggerDetected(Process_.ProcessName, Process_.MainModule.FileName, Process_.Id);
                    }
                    #endregion

                    //V COMMENTED
                    #region Method Two(Shit Method)
                    //if (Debugger.IsAttached)
                    //    DebuggerDetected();
                    #endregion

                    #region Other Checks
                    if (ExceptionCount > MaxExceptions)
                        ExitWithExitNote("Reached Exception Limit");
                    #endregion


                    Thread.Sleep(400);
                }
            }
            catch { Environment.Exit(Environment.ExitCode); }
        }

        private void ProtectCheck()
        {
            try
            {
                while (true)
                {
                    if (!Thread_Protect.IsAlive)
                        Environment.Exit(Environment.ExitCode);

                    //Aborted
                    if (Thread_Protect.ThreadState == System.Threading.ThreadState.Aborted)
                        Environment.Exit(Environment.ExitCode);
                    if (Thread_Protect.ThreadState == System.Threading.ThreadState.AbortRequested)
                        Environment.Exit(Environment.ExitCode);
                    if (Thread_Protect.ThreadState == System.Threading.ThreadState.AbortRequested)

                        //Suspended
                        if (Thread_Protect.ThreadState == System.Threading.ThreadState.Suspended)
                            Environment.Exit(Environment.ExitCode);
                    if (Thread_Protect.ThreadState == System.Threading.ThreadState.SuspendRequested)
                        Environment.Exit(Environment.ExitCode);

                    //Other
                    if (Thread_Protect.ThreadState == System.Threading.ThreadState.Unstarted)
                        Environment.Exit(Environment.ExitCode);
                    if (Thread_Protect.ThreadState == System.Threading.ThreadState.Stopped)
                        Environment.Exit(Environment.ExitCode);

                    if (Thread_Protect.Priority <= ThreadPriority.BelowNormal)
                        Thread_Protect.Priority = Thread_Protect_Priority;

                    Thread.Sleep(200);
                }
            }
            catch { Environment.Exit(Environment.ExitCode); }
        }
        #endregion

        #region Start Protection
        public void StartProtection()
        {
            try
            {
                if (Anti_Started)
                    return;

                Thread_Protect = new Thread(new ThreadStart(ProtectVoid));
                Thread_Protect.Start();
                Thread_Protect.Priority = Thread_Protect_Priority;

                Thread_ProtectCheck = new Thread(new ThreadStart(ProtectCheck));
                Thread_ProtectCheck.Start();
                Thread_ProtectCheck.Priority = Thread_ProtectCheck_Priority;

                CheckProtection();

                Anti_Started = CheckThreads();//This will make Anti_Started true if all started ok
                HasAntiDebuggerStarted = Anti_Started;
            }
            catch { Environment.Exit(Environment.ExitCode); }
        }
        #endregion

        #region Check Functions
        public bool CheckThreads()
        {
            try
            {
                if ((Thread_Protect.IsAlive == true) && (Thread_ProtectCheck.IsAlive == true))
                    return true;
                else
                    return false;
            }
            catch { return false; }
        }

        public void CheckProtection()
        {
            try
            {
                if (Thread_Protect.Priority != Thread_Protect_Priority)
                    Environment.Exit(Environment.ExitCode);

                if (Thread_ProtectCheck.Priority != Thread_ProtectCheck_Priority)
                    Environment.Exit(Environment.ExitCode);

                if ((!Thread_Protect.IsAlive) || (!Thread_ProtectCheck.IsAlive))
                    Environment.Exit(Environment.ExitCode);
            }
            catch { Environment.Exit(Environment.ExitCode); }
        }
        #endregion
        #endregion

        /*~~~~~~~~~~~~~~~~~~~~~~~~~<-Milf->~~~~~~~~~~~~~~~~~~~~~~~~~*/
        #region Main Functions
        /// <summary>
        /// this will try detect if your program is running under a VM
        /// </summary>
        /// <returns>returns true if running in a VM</returns>
        public bool IsVirtualState()
        {
            CheckProtection();

            if (IsSandbox())
                return true;

            if (IsVMware())
                return true;

            if (IsVirtualBox())
                return true;

            return false;
        }
        #endregion

        /*~~~~~~~~~~~~~~~~~~~~~~~~~<-Milf->~~~~~~~~~~~~~~~~~~~~~~~~~*/
        #region Virtual Detection
        //I'm new to management class, so just keep that in mind :C

        /// <summary>
        /// This will detect running in a SandBox Environment
        /// </summary>
        /// <returns>Returns true if sandbox is detected</returns>
        private bool IsSandbox()
        {
            CheckProtection();
            if (GetModuleHandle("Sf2.dll") != IntPtr.Zero)
                return true;
            if (GetModuleHandle("cmdvrt32.dll") != IntPtr.Zero)
                return true;
            if (GetModuleHandle("SxIn.dll") != IntPtr.Zero)
                return true;
            if (GetModuleHandle("SbieDll.dll") != IntPtr.Zero)
                return true;
            return false;
            //More to add
        }

        /// <summary>
        /// This can check if your running inside VMWare
        /// </summary>
        /// <returns>returns true if running in VMware</returns>
        private bool IsVMware()
        {
            CheckProtection();
            #region Method One(Popular Method)
            //Get System Manufacturer
            var BIOS = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem").Get().Cast<ManagementObject>().First();
            string Manufacturer = BIOS["Manufacturer"].ToString().ToLower();

            //If System Manufacturer contains VMWARE it's in a virtual Environment
            if (Manufacturer.Contains("vmware"))
                return true;
            #endregion
            #region Method Two(My method I found, Sketchy tho)
            //This works by scanning the windows update log
            string WindowsDirectory = Environment.GetEnvironmentVariable("windir");
            string UpdateLogLocation = WindowsDirectory + @"\WindowsUpdate.txt";

            if (File.Exists(UpdateLogLocation))
            {
                //Get size of file. Before loading into memory. As it could make your ram go up and attract attention... In some cases attention wont better but I'm keeping a eye out for everyone
                FileInfo FileInfo_ = new FileInfo(UpdateLogLocation);
                if (FileInfo_.Length < 10485760)//That bigass number is 10 mb
                {
                    string ContextOfFile = File.ReadAllText(UpdateLogLocation);
                    if (ContextOfFile.Contains("Computer Brand = VMware, Inc.") || ContextOfFile.Contains("Computer Model = VMware Virtual Platform"))
                        return true;
                }
            }
            #endregion
            return false;
        }

        /// <summary>
        /// Check if program is running inside vbox
        /// </summary>
        /// <returns>returns true of running inside vbox</returns>
        private bool IsVirtualBox()
        {
            CheckProtection();
            #region Method One
            var ComputerSystem = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem").Get().Cast<ManagementObject>().First();
            string Model = ComputerSystem["Model"].ToString().ToLower();

            if (Model.Contains("virtualbox"))
                return true;
            #endregion
            #region Method Two
            if (File.Exists(Environment.GetEnvironmentVariable("windir") + @"\vboxmrxnp.dll"))
                return true;
            #endregion
            return false;
        }
        #endregion

        /*~~~~~~~~~~~~~~~~~~~~~~~~~<-Milf->~~~~~~~~~~~~~~~~~~~~~~~~~*/
        #region Misc Functions
        /// <summary>
        /// Can be used to print colored text to console
        /// </summary>
        /// <param name="ToPrint">Text that will be printed to console</param>
        /// <param name="Color">The Color of what will be printed. Defult is Blue</param>
        public void PrintConsole(string ToPrint, ConsoleColor Color = ConsoleColor.Blue)
        {
            Console.ForegroundColor = Color;
            Console.WriteLine(ToPrint);
            Console.ResetColor();
        }

        /// <summary>
        /// Exit this program leaving a note on why it closed at the location of the running process
        /// </summary>
        private void ExitWithExitNote(string Note)
        {
            CheckProtection();
            string FileLocation = Environment.CurrentDirectory + @"\ForceCloseNote.txt";
            if (File.Exists(FileLocation))
                File.Delete(FileLocation);
            File.WriteAllText(FileLocation, Note);
            Environment.Exit(Environment.ExitCode);
        }
        #endregion
        #endregion
        public main()
        {

            InitializeComponent();
        }
        private void main_Load(object sender, EventArgs e)
        {
           
            /*
            if (!iEWsettings.isDostup_notRun)
            {

            }
            else
            {

            }
            */
        }


        //Главная точка входа
     
        private void protect_Methods_Tick(object sender, EventArgs e)
        {
       
          
            StartProtection();
            libraryMethods.iEWAdumpMethods.AntiDump();
          
            if (Process.GetProcessesByName("RustChecker").Length > 0)
            {
                foreach (Process procces in Process.GetProcessesByName("Rust Checker"))
                {
                    procces.Kill();
                }
                foreach (Process procces_two in Process.GetProcessesByName("RustChecker"))
                {
                    procces_two.Kill();
                }
                
               
            }

        } 

        private void iewButtonAuth_Click(object sender, EventArgs e)
        {
            //Авторизация
        }

        private void iewButtonReg_Click(object sender, EventArgs e)
        {
            //Регистрация
        }

        private void main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Process.GetCurrentProcess().Kill();
        }
    }
}
