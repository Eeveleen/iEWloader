﻿using System.Windows.Forms;


public class iEWMessage
{
    public static void CreateMessage(string Mess, string Title, MessageBoxIcon icon)
    {
        MessageBox.Show(Mess, Title, MessageBoxButtons.OK, icon);
    }
}

