﻿using System.IO;
using System.Net;
using System.Text;

public class iEWwebData
{
    //get запросы
    private static string GET(string Url, string Data)
    {
        System.Net.WebRequest req = System.Net.WebRequest.Create(Url + "?" + Data);
        System.Net.WebResponse resp = req.GetResponse();
        System.IO.Stream stream = resp.GetResponseStream();
        System.IO.StreamReader sr = new System.IO.StreamReader(stream);
        string Out = sr.ReadToEnd();
        sr.Close();
        return Out;
    }
    //Получение Текстовой информации по ссылке
    public static string pGetInformation(string Url)
    {
        try
        {
            HttpWebRequest Запрос = (HttpWebRequest)WebRequest.Create(Url);
            HttpWebResponse Ответ = (HttpWebResponse)Запрос.GetResponse();
            return new StreamReader(Ответ.GetResponseStream(), Encoding.Default).ReadToEnd();
        }
        catch 
        {
            return null;
        }
    }
    //Скачка файла
    public static void DownloadFile(string URL, string saveCataloge)
    {
        try
        {
            new WebClient().DownloadFile(URL, saveCataloge);
        }
        catch 
        {
        }
    }

}
