﻿using System;
using System.Runtime.InteropServices;
using System.Text;

public class iEWwinAPI
{

    #region ' Inject Dll CreateRemoteThread '

    [DllImport("kernel32")]
    public static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, UIntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, out IntPtr lpThreadId);

    #endregion

    #region ' OpenProcess(ProcessHandle) '

    [DllImport("kernel32.dll")]
    public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

    #endregion

    #region ' CloseHandle '

    [DllImport("kernel32.dll")]
    public static extern Int32 CloseHandle(IntPtr hObject);

    #endregion

    #region ' VirtualFreeEx '

    [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
    static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, UIntPtr dwSize, uint dwFreeType);

    #endregion

    #region ' GetProcAddress '

    [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true)]
    public static extern UIntPtr GetProcAddress(IntPtr hModule, string procName);

    #endregion

    #region ' VirtualProtectEx '

    [DllImport("kernel32.dll")]
    public static extern bool VirtualProtectEx(IntPtr hProcess, IntPtr lpAddress, UIntPtr dwSize, uint flNewProtect, out uint lpflOldProtect);

    #endregion

    #region ' ReadProcessMemory '

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern bool ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint dwSize, uint lpNumberOfBytesRead);

    #endregion

    #region ' VirtualAllocEx '

    [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
    static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

    #endregion

    #region ' WriteProcessMemory '

    [DllImport("kernel32.dll")]
    public static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, uint lpNumberOfBytesWritten);

    #endregion

    #region ' GetModuleHandle '

    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    public static extern IntPtr GetModuleHandle(string lpModuleName);

    #endregion

    #region ' WaitForSingleObject '

    [DllImport("kernel32", SetLastError = true, ExactSpelling = true)]
    internal static extern Int32 WaitForSingleObject(IntPtr handle, Int32 milliseconds);

    #endregion

    #region ' FindWindow '

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern IntPtr FindWindow(string className, string windowName);

    #endregion

    #region ' SendMessage '

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

    #endregion

    #region ' GetAsyncKeyState '

    [DllImport("user32.dll")]
    public static extern short GetAsyncKeyState(int vKey);

    #endregion

    #region ' GetKeyState '

    [DllImport("user32.dll")]
    public static extern short GetKeyState(int vKey);

    #endregion

    #region ' WritePrivateProfileString '

    [DllImport("kernel32")]
    public static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

    #endregion

    #region 'GetPrivateProfileString  '

    [DllImport("kernel32")]
    public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

    #endregion

    #region ' printf '

    [DllImport("msvcrt.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]
    public static extern int printf(string formatspecifier, int lhs, int rhs, int total);

    #endregion

    #region ' Inject Mapping '

    [DllImport("BLoad.dll", CharSet = CharSet.Auto, SetLastError = true, CallingConvention = CallingConvention.Cdecl)]
    public static extern bool Ex_Inject(UInt32 pID, [In][MarshalAs(UnmanagedType.LPStr)]string d_Patch);
    
    #endregion

}

