﻿using System;
using System.Threading;

public class iEWsmartThread
{
    //Старт Потока
    public static void StartThread(string ThreadName, ThreadStart Therading)
    {
        Thread t = new Thread(Therading);
        t.IsBackground = true;
        t.Name = ThreadName;
        t.Start();
    }
    //Остановка потока
    public static void StopThread(string ThreadName, ThreadStart Therading)
    {
        Thread t = new Thread(Therading);
        t.IsBackground = true;
        t.Name = ThreadName;
        t.Abort();
    }
    //Возвращает значение, показывающее принадлежит ли поток к группе управляемых потоков.
    public static bool GetThreadPool(ThreadStart Therading)
    {
        Thread t = new Thread(Therading);
        return t.IsThreadPoolThread;
    }
    //Получение Id идентификатора заданого потокак
    public static Int32 GetThreadId(ThreadStart Therading)
    {
        Thread t = new Thread(Therading);
        return t.ManagedThreadId;
    }
    //Полуение приоритета заданого потока
    public static string GetThreadPriority(ThreadStart Therading)
    {
        Thread t = new Thread(Therading);
        return t.Priority.ToString();
    }
    //Установка приоритета заданого потока
    public static ThreadPriority SetThreadPriority(ThreadStart Therading, ThreadPriority Priority)
    {
        Thread t = new Thread(Therading);
        return t.Priority = Priority;
    }
    //Приостанавливает работу текущего потока на некое время (в милисекундах)
    public static void SleepThread(int Miliseconds)
    {
        Thread.Sleep(Miliseconds);
    }
}
