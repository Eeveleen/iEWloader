﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.NetworkInformation;

public class iEWhost
{
    public static bool iew_checkingHost()
    {
        try
        {
            IPStatus iew_toConnect = IPStatus.Unknown;
            iew_toConnect = new Ping().Send(iEWloader.iEWsettings.iewHostname).Status;
            if (iew_toConnect != IPStatus.Success)
            {
                iEWloader.iEWsettings.iewServer = false;
                return iEWloader.iEWsettings.iewServer;
            }
            else
            {
                iEWloader.iEWsettings.iewServer = true;
                return iEWloader.iEWsettings.iewServer;
            }
        }
        catch
        {
            return iEWloader.iEWsettings.iewServer;
        }
    }
}
