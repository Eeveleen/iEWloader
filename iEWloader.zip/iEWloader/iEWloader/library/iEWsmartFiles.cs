﻿using System;
using System.IO;
using System.Windows.Forms;

public class iEWsmartFiles
{
    //Получает значение, показывающее существует ли файл по заданному пути
    public static bool pFileExists(string FilePatch)
    {
        return new FileInfo(FilePatch).Exists;
    }
    //Получает значение, показывающее существует ли директория(папка) по заданному пути
    public static bool pDirectoryExists(string FilePatch)
    {
        return new DirectoryInfo(FilePatch).Exists;
    }
    //Удаляет файл, если он существует по заданному пути.
    public static void pDelFile(string FilePatch)
    {
        if (pFileExists(FilePatch))
        {
            try
            {
                File.Delete(FilePatch);
            }
            catch (Exception E)
            {
                iEWMessage.CreateMessage("Error, file not found: " + E.ToString(), "Error!!", MessageBoxIcon.Information);
            }
        }
    }
    //Создание директории
    public static void pCreateDirectory(string DirectoryName)
    {
        try
        {
            if (!pDirectoryExists(DirectoryName))
            {
                new DirectoryInfo(DirectoryName).Create();
            }
            else
            {
                new DirectoryInfo(DirectoryName).Delete();
                new DirectoryInfo(DirectoryName).Create();
            }
        }
        catch (Exception Ex)
        {
            MessageBox.Show("Directory is using: " + Ex.ToString());
        }
    }
    //Удаление Директории
    public static void pDeleteDirectory(string DirectoryName)
    {
        try
        {
            if (pDirectoryExists(DirectoryName))
            {
                new DirectoryInfo(DirectoryName).Delete();
            }
        }
        catch (Exception Ex)
        {
           iEWMessage.CreateMessage("Directory is using: " + Ex.ToString(),"Error", MessageBoxIcon.Information);
        }
    }
    //Вызгрузка файла из ресурсов
    public static void pUnloadRecource(string DirectoryName)
    {
        
    }
}

