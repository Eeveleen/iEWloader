﻿using System;
using System.Diagnostics;

public class iEWprocess
{
    public static Process[] m_pProcess = Process.GetProcessesByName(iEWloader.iEWsettings.iewPr0c);

    //Поиск процесса по имени
    public static bool FindProcessByName(string pName)
    {
        Process[] Game = Process.GetProcessesByName(pName);
        if (Game.Length != 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    //Поиск процесса по id
    public static bool FindProcessById(int pID)
    {
        Process Game = Process.GetProcessById(pID);
        if (Game.Id != 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    //Поиск и убийство процессов из моссива
    public static void FindAndKillProceses(string[] ProcessesNamesA)
    {
        foreach (string name in ProcessesNamesA)
        {
            foreach (Process p1 in Process.GetProcessesByName(name))
            {
                try
                {
                    p1.Kill();
                }
                catch { }
            }
        }
    }
    //Убийство Процесса по имени
    public static void KillProcess(string pName)
    {
        if (FindProcessByName(pName))
        {
            try
            {
                foreach (Process Proc in Process.GetProcessesByName(pName))
                {
                    Proc.Kill();
                }
            }
            catch (Exception E)
            {
                Console.WriteLine("Error, kill process: " + E.ToString());
            }
        }
    }
    //Получение id процесса по имени
    public static int ProcessID(String proc)
    {
        Process[] ProcList = Process.GetProcessesByName(proc);
        return ProcList[0].Id;
    }
    //Запуск Процесса
    public static void OpenProcess(string FileProcName)
    {
        try
        {
            Process.Start(FileProcName);
        }
        catch { }
    }
    //Открытие URL
    public static void OpenURL(string URL)
    {
        OpenProcess("http://" + URL);
    }
    //Получение Хендлов Собственного процесса
    public static IntPtr GetMyHandle()
    {
        return Process.GetCurrentProcess().Handle;
    }
    //Получение Хендлов некого процесса по id
    public static IntPtr GetProcessHandleById(int pID)
    {
        return Process.GetProcessById(pID).Handle;
    }
}

