﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iEWloader
{
    class iEWsettings
    {
  
       public static bool isDostup_notRun = true;
       //
       public static string iewSubpath_dir = @"SkypeTemp\Updater\Microsoft\skypeconfig";
       //патч для с данных сайта
       public static string iewPath_webLink = "";
       //патч для хранения информации (длл, обновления)
       public static string iewPath_libDir = Path.GetTempPath() + "\\Rar$DRa0.2633";
       //хост
       public static string iewHostname = "exclusivecheats.ru";
       //проверка доступа хоста.
       public static bool iewServer = false;
       //Процесс
       public static string iewPr0c = null;


    }
}
