﻿namespace iEWloader
{
    partial class main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.protect_Methods = new System.Windows.Forms.Timer(this.components);
            this.iewLogin_text = new MetroFramework.Controls.MetroTextBox();
            this.iewPass_text = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // protect_Methods
            // 
            this.protect_Methods.Enabled = true;
            this.protect_Methods.Interval = 1;
            this.protect_Methods.Tick += new System.EventHandler(this.protect_Methods_Tick);
            // 
            // iewLogin_text
            // 
            this.iewLogin_text.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.iewLogin_text.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.iewLogin_text.Location = new System.Drawing.Point(105, 101);
            this.iewLogin_text.Multiline = true;
            this.iewLogin_text.Name = "iewLogin_text";
            this.iewLogin_text.Size = new System.Drawing.Size(224, 25);
            this.iewLogin_text.TabIndex = 3;
            this.iewLogin_text.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // iewPass_text
            // 
            this.iewPass_text.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.iewPass_text.FontWeight = MetroFramework.MetroTextBoxWeight.Light;
            this.iewPass_text.Location = new System.Drawing.Point(105, 132);
            this.iewPass_text.Multiline = true;
            this.iewPass_text.Name = "iewPass_text";
            this.iewPass_text.Size = new System.Drawing.Size(224, 25);
            this.iewPass_text.TabIndex = 4;
            this.iewPass_text.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(43, 101);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(44, 19);
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "Login:";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(27, 132);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(66, 19);
            this.metroLabel2.TabIndex = 6;
            this.metroLabel2.Text = "Password:";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Location = new System.Drawing.Point(0, 380);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(613, 27);
            this.panel1.TabIndex = 8;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 259);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.iewPass_text);
            this.Controls.Add(this.iewLogin_text);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "main";
            this.Resizable = false;
            this.ShadowType = MetroFramework.Forms.MetroForm.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Purple;
            this.Text = "ExclusiveLoader";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.main_FormClosing);
            this.Load += new System.EventHandler(this.main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer protect_Methods;
        private MetroFramework.Controls.MetroTextBox iewLogin_text;
        private MetroFramework.Controls.MetroTextBox iewPass_text;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.Panel panel1;
    }
}

