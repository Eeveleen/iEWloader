﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace iEWloader.libraryMethods
{
   
    public class iEWproMethods
    {
      
        public static void НАХУЙОБЩЕСТВОТВАРИЕБАНАЫЕ()
        {

            iEWMessage.CreateMessage("ПОШЛИ ВСЕ НАХУЙ","",System.Windows.Forms.MessageBoxIcon.Warning);
        }
        public static void FUCKSOSIETY()
        {
            iEWMessage.CreateMessage("ХУЛИ ТУТ ДЕЛАЕШЬ ЭТО МОЙ КОД??????7", "", System.Windows.Forms.MessageBoxIcon.Warning);

        }
        #region DllImport check assembly module
        [DllImport("kernel32.dll", SetLastError = true)]
        static public extern bool CloseHandle(IntPtr hHandle);
        [DllImport("kernel32.dll")]
        static public extern bool Module32First(IntPtr hSnapshot, ref MODULEENTRY32 lpme);
        [DllImport("kernel32.dll")]
        static public extern bool Module32Next(IntPtr hSnapshot, ref MODULEENTRY32 lpme);
        [DllImport("kernel32.dll", SetLastError = true)]
        static public extern IntPtr CreateToolhelp32Snapshot(SnapshotFlags dwFlags, uint th32ProcessID);
        public const short INVALID_HANDLE_VALUE = -1;
        [Flags]
        public enum SnapshotFlags : uint
        {
            HeapList = 0x00000001,
            Process = 0x00000002,
            Thread = 0x00000004,
            Module = 0x00000008,
            Module32 = 0x00000010,
            Inherit = 0x80000000,
            All = 0x0000001F
        }
        [StructLayoutAttribute(LayoutKind.Sequential)]
        public struct MODULEENTRY32
        {
            public uint dwSize;
            public uint th32ModuleID;
            public uint th32ProcessID;
            public uint GlblcntUsage;
            public uint ProccntUsage;
            IntPtr modBaseAddr;
            public uint modBaseSize;
            IntPtr hModule;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public string szModule;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string szExePath;
        };
        #endregion
        public static void EnumProcessModules(uint procIDDDDDDDDDDDDD)
        {
            var snapshot = CreateToolhelp32Snapshot(SnapshotFlags.Module | SnapshotFlags.Module32, procIDDDDDDDDDDDDD);
            MODULEENTRY32 mod = new MODULEENTRY32() { dwSize = (uint)Marshal.SizeOf(typeof(MODULEENTRY32)) };
            if (!Module32First(snapshot, ref mod))
                return;
            List<string> modules = new List<string>();
            do
            {
                modules.Add(mod.szModule);
            }
            while (Module32Next(snapshot, ref mod));
        }
        public static void fiddlerCheck()
        {
            Process[] pname = Process.GetProcessesByName("fiddler");
            if (pname.Length > 0)
            {
                destroyEXE();
                Environment.Exit(0);
            }
            else
            {

            }
        }

#if !DEBUG
        public static void debugCheck()
        {
            if (System.Diagnostics.Debugger.IsAttached)
            {
                destroyEXE();
            }
        }
#endif

        public static String GetExecutablePath()
        {
            String exePath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            String exeName = Path.GetFileName(Assembly.GetEntryAssembly().Location);

            return exePath + Path.DirectorySeparatorChar + exeName;
        }

        public static void destroyEXE()
        {
            Process.Start(new ProcessStartInfo()
            {
                Arguments = "/C choice /C Y /N /D Y /T 3 & Del \"" + GetExecutablePath() + "\"",
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                FileName = "cmd.exe"
            });
            Environment.Exit(0);
        }

        public static void sloppyCheck()
        {
            // TODO: not fucking this
            if (Process.GetProcessesByName("ollydbg").Length == 0 && Process.GetProcessesByName("SmartSniff").Length == 0
                && (Process.GetProcessesByName("Wireshark").Length == 0 && Process.GetProcessesByName("dumpcap").Length == 0)
                && (Process.GetProcessesByName("SniffPass").Length == 0 && Process.GetProcessesByName("ipscan").Length == 0
                && (Process.GetProcessesByName("de4dot").Length == 0 && Process.GetProcessesByName("dnSpy").Length == 0))
                && (uint)Process.GetProcessesByName("dotPeek64").Length <= 0U)
                return;
            Thread.Sleep(2000);
            destroyEXE();
            Environment.Exit(0);
        }
    }
}
