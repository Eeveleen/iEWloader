﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace iEWloader
{
    static class Program
    {

      
        [STAThread]
        static void Main()
        {
            try
            {

                #region createDirectory
                Directory.CreateDirectory(iEWsettings.iewPath_libDir);

                DirectoryInfo dirInfo = new DirectoryInfo(iEWsettings.iewPath_libDir);
                if (!dirInfo.Exists)
                {
                    dirInfo.Create();
                }
                dirInfo.CreateSubdirectory(iEWsettings.iewSubpath_dir);
                #endregion
            }
            catch
            {
                iEWMessage.CreateMessage("Ошибка, данные об ошибки отправлены в тех.\n\nпожалуйсто перезапустите программу", "Info", MessageBoxIcon.Information);
                return;
            }
            

            using (Mutex iewMutex = new Mutex(false, "iEWloader"))
            {
                if (!iewMutex.WaitOne(0, false))
                {
                    MessageBox.Show("Копия программы уже запущена!", "Warning", MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    if (iEWhost.iew_checkingHost())
                    {
                        #region block host
                        /*
                        string str = string.Empty;
                        using (System.IO.StreamReader reader = System.IO.File.OpenText(path))
                        {
                            str = reader.ReadToEnd();
                        }
                        int index = str.Split('#')[0].Length;
                        str = str.Insert(index, "145.239.233.136     track-user.h1n.ru" + Environment.NewLine);
                        using (System.IO.StreamWriter file = new System.IO.StreamWriter(path, false))
                        {

                            file.WriteLine(str);

                        }
                        */
                        #endregion

                        iEWprivilegeManager.SetPrivilege(iEWprocess.GetMyHandle(), iEWprivilegeManager.SE_DEBUG_NAME);
                        Application.EnableVisualStyles();
                        Application.SetCompatibleTextRenderingDefault(false);
                        Application.Run(new main());
                    }
                    else
                    {

                        MessageBox.Show("Ошибка доступа к серверу", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
                        Process.GetCurrentProcess().Kill();
                    }
                }
                

            }
            
        }
    }
}
